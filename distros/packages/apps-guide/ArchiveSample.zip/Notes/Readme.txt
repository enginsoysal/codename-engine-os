Extracted by the original Engine OS archive frontend.
